// test.cpp : Google Test unit tests for std::vector

#include "gtest/gtest.h"
#include <vector>
#include <memory>
#include <stdexcept>
#include <cassert>
#include <cstdlib>
#include <ctime>

// the global test environment setup and tear down
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    void SetUp() override
    {
        srand(static_cast<unsigned>(time(nullptr)));
    }

    void TearDown() override {}
};

// create our test class to house shared data between tests
class CollectionTest : public ::testing::Test
{
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        collection->clear();
        collection.reset(nullptr);
    }

    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// ---------- TEST CASES ----------

// Test that a collection is created and not null
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty on creation
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Demonstration test (always fails if enabled)
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// Test adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    ASSERT_TRUE(collection->empty());
    add_entries(1);
    EXPECT_EQ(collection->size(), 1);
}

// Test adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);
    EXPECT_EQ(collection->size(), 5);
}

// Test that max size is always >= size
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize)
{
    std::vector<int>::size_type sizes[] = {0, 1, 5, 10};
    for (auto s : sizes)
    {
        collection->clear();
        if (s > 0) add_entries(s);
        EXPECT_GE(collection->max_size(), collection->size());
    }
}

// Test that capacity is always >= size
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize)
{
    std::vector<int>::size_type sizes[] = {0, 1, 5, 10};
    for (auto s : sizes)
    {
        collection->clear();
        if (s > 0) add_entries(s);
        EXPECT_GE(collection->capacity(), collection->size());
    }
}

// Test resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
    collection->resize(5);
    EXPECT_EQ(collection->size(), 5);
}

// Test resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
    collection->resize(10);
    collection->resize(3);
    EXPECT_EQ(collection->size(), 3);
}

// Test resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZero)
{
    collection->resize(10);
    collection->resize(0);
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}

// Test clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    add_entries(5);
    collection->clear();
    EXPECT_TRUE(collection->empty());
}

// Test erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseAllEntries)
{
    add_entries(5);
    collection->erase(collection->begin(), collection->end());
    EXPECT_TRUE(collection->empty());
}

// Test reserve increases capacity but not size
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    add_entries(5);
    auto old_capacity = collection->capacity();
    collection->reserve(old_capacity + 50);
    EXPECT_GE(collection->capacity(), old_capacity + 50);
    EXPECT_EQ(collection->size(), 5);
}

// Negative test: at() throws exception out of range
TEST_F(CollectionTest, AccessOutOfRangeThrowsException)
{
    add_entries(3);
    EXPECT_THROW(collection->at(10), std::out_of_range);
}

// Custom positive test: back() returns last element
TEST_F(CollectionTest, BackReturnsLastElement)
{
    add_entries(3);
    int last = collection->back();
    EXPECT_EQ(last, collection->at(collection->size() - 1));
}

// Custom negative test: at() on empty throws exception
TEST_F(CollectionTest, AtOnEmptyThrowsException)
{
    EXPECT_THROW(collection->at(0), std::out_of_range);
}